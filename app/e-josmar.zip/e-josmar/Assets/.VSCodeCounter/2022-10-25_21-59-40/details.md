# Details

Date : 2022-10-25 21:59:40

Directory c:\\Users\\rafak\\Desktop\\e-josmar\\Assets\\scripts

Total : 27 files,  1395 codes, 0 comments, 187 blanks, all 1582 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Scripts/AllRequestsDropdown.cs](/Scripts/AllRequestsDropdown.cs) | C# | 55 | 0 | 10 | 65 |
| [Scripts/AuthButton.cs](/Scripts/AuthButton.cs) | C# | 82 | 0 | 10 | 92 |
| [Scripts/CancelRequestButton.cs](/Scripts/CancelRequestButton.cs) | C# | 12 | 0 | 3 | 15 |
| [Scripts/CheckKeys.cs](/Scripts/CheckKeys.cs) | C# | 101 | 0 | 14 | 115 |
| [Scripts/ClosePanelButton.cs](/Scripts/ClosePanelButton.cs) | C# | 21 | 0 | 3 | 24 |
| [Scripts/ConfirmRequestButton.cs](/Scripts/ConfirmRequestButton.cs) | C# | 76 | 0 | 10 | 86 |
| [Scripts/ContentJson.cs](/Scripts/ContentJson.cs) | C# | 53 | 0 | 9 | 62 |
| [Scripts/EditUserButton.cs](/Scripts/EditUserButton.cs) | C# | 72 | 0 | 8 | 80 |
| [Scripts/ExitButton.cs](/Scripts/ExitButton.cs) | C# | 13 | 0 | 2 | 15 |
| [Scripts/Key.cs](/Scripts/Key.cs) | C# | 16 | 0 | 1 | 17 |
| [Scripts/LoadKeys.cs](/Scripts/LoadKeys.cs) | C# | 60 | 0 | 8 | 68 |
| [Scripts/OnRequestPanelActive.cs](/Scripts/OnRequestPanelActive.cs) | C# | 53 | 0 | 10 | 63 |
| [Scripts/OpenAllRequestsButton.cs](/Scripts/OpenAllRequestsButton.cs) | C# | 17 | 0 | 3 | 20 |
| [Scripts/OpenRequestPanelButton.cs](/Scripts/OpenRequestPanelButton.cs) | C# | 30 | 0 | 6 | 36 |
| [Scripts/OpenUpdatePanelDropdown.cs](/Scripts/OpenUpdatePanelDropdown.cs) | C# | 57 | 0 | 8 | 65 |
| [Scripts/README.md](/Scripts/README.md) | Markdown | 2 | 0 | 1 | 3 |
| [Scripts/SaveSystem.cs](/Scripts/SaveSystem.cs) | C# | 28 | 0 | 3 | 31 |
| [Scripts/ShowHidePasswordButton.cs](/Scripts/ShowHidePasswordButton.cs) | C# | 24 | 0 | 3 | 27 |
| [Scripts/SwitchPanelButton.cs](/Scripts/SwitchPanelButton.cs) | C# | 26 | 0 | 5 | 31 |
| [Scripts/SwitchSceneButton.cs](/Scripts/SwitchSceneButton.cs) | C# | 13 | 0 | 3 | 16 |
| [Scripts/SwitchTimeInputButton.cs](/Scripts/SwitchTimeInputButton.cs) | C# | 29 | 0 | 3 | 32 |
| [Scripts/UpdateKeyStatusButton.cs](/Scripts/UpdateKeyStatusButton.cs) | C# | 157 | 0 | 21 | 178 |
| [Scripts/User.cs](/Scripts/User.cs) | C# | 20 | 0 | 5 | 25 |
| [Scripts/Utilities.cs](/Scripts/Utilities.cs) | C# | 172 | 0 | 17 | 189 |
| [Scripts/VerifyRequestDateButton.cs](/Scripts/VerifyRequestDateButton.cs) | C# | 55 | 0 | 8 | 63 |
| [Scripts/VerifyTime.cs](/Scripts/VerifyTime.cs) | C# | 140 | 0 | 12 | 152 |
| [Scripts/fodasebtn.cs](/Scripts/fodasebtn.cs) | C# | 11 | 0 | 1 | 12 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)