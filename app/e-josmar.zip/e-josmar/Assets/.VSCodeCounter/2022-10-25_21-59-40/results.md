# Summary

Date : 2022-10-25 21:59:40

Directory c:\\Users\\rafak\\Desktop\\e-josmar\\Assets\\scripts

Total : 27 files,  1395 codes, 0 comments, 187 blanks, all 1582 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C# | 26 | 1,393 | 0 | 186 | 1,579 |
| Markdown | 1 | 2 | 0 | 1 | 3 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 27 | 1,395 | 0 | 187 | 1,582 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)