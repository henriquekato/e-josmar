public class Current
{
    public static int currentRoom;
    public static string currentTimeStart;
    public static string currentTimeEnd;
    public static string currentDateDay;
    public static Key currentKey;
}
