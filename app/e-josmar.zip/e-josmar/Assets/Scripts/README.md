# Aplicativo e-josmar

Esse é o repositório dos scripts do aplicativo e-josmar para celulares que foi feito na plataforma Unity.

Ele se comunica com a API [server-josmar](https://github.com/mocno/server-josmar) e armário "e-josmar".
