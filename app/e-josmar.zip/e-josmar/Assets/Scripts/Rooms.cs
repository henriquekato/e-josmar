using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rooms : MonoBehaviour
{
    public enum Room
    {
        sala1 = 1,
        sala2 = 2,
        lab3 = 3,
        lab4 = 4
    }
}
